/*  
Revised: Revised: 130605.1300
*/

var minHeight = 550;
var minWidth = 515;
var olUrlBase = "http://go.microsoft.com/fwlink/?LinkId=306767";

function init() {
    var x = window.innerWidth;
    var y = window.innerHeight;
    var resize = false;

    if (x < minWidth) {
        x = minWidth;
        resize = true;
    }
    if (y < minHeight) {
        y = minHeight;
        resize = true;
    }
    if (resize) {
        window.resizeTo(x, y);
    }

    setOnlineHelpLink();
}

function setOnlineHelpLink() {
    document.getElementById('goOnlineBtn').setAttribute('href', olUrlBase);
}